// 7. Write a JavaScript program to check whether a number is even or not.  

