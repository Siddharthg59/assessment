function countOcc(str,char){
    const map=new Map();
    const arrofstr=str.toLowerCase().split(" "); // Convert the string to lowercase and split into words
    for(let word of arrofstr){
        if(map.has(word)){
            map.set(word, map.get(word) + 1);
        }
        else{
            map.set(word, 1);
        }
    }
    return map.get(char.toLowerCase()) || 0; // Return the count of the character or 0 if not found

}
console.log(countOcc("hello world hello", "hello")); // 2