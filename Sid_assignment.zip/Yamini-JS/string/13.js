function repeat(str, n = 1) {
  return str.repeat(n);
}
