function uncamelize(str, separator = ' ') {
  return str
    .replace(/([a-z])([A-Z])/g, '$1' + separator + '$2')  // insert separator between lowercase-uppercase
    .toLowerCase();                                       // convert entire string to lowercase
}
