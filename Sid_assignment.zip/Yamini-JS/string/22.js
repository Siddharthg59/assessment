function subStrAfterChars(str, char, flag) {
  const index = str.indexOf(char);
  if (index === -1) return '';  // char not found

  if (flag === 'a') {
    // Return substring BEFORE the character
    return str.substring(0, index);
  } else if (flag === 'b') {
    // Return substring AFTER the character
    return str.substring(index + 1);
  } else {
    return '';  // invalid flag
  }
}
