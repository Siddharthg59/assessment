function protect_email(email) {
  let [user, domain] = email.split("@"); // Split into username and domain
  let visiblePart = user.slice(0, user.indexOf("_") !== -1 ? user.indexOf("_") : 4); // up to "_" or 4 characters
  return visiblePart + "...@" + domain;
}
