function case_insensitive_search(str, searchTerm) {
  // Convert both string and search term to lowercase for comparison
  if (str.toLowerCase().includes(searchTerm.toLowerCase())) {
    return "Matched";
  } else {
    return "Not Matched";
  }
}

// Test cases:
console.log(case_insensitive_search('JavaScript Exercises', 'exercises'));    // "Matched"
console.log(case_insensitive_search('JavaScript Exercises', 'Exercises'));    // "Matched"
console.log(case_insensitive_search('JavaScript Exercises', 'Exercisess'));   // "Not Matched"
