function humanize_format(number) {
    if (number === undefined || number === null) return '';

    const n = Number(number);
    if (isNaN(n)) return '';

    const suffixes = ['th', 'st', 'nd', 'rd'];
    const v = n % 100;

    if (v >= 11 && v <= 13) {
        return n + 'th';
    } else {
        const lastDigit = n % 10;
        return n + (suffixes[lastDigit] || 'th');
    }
}
