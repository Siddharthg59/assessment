function camelcase(str){

    return str.toLowerCase().split(/[\s_-]+/).map((word)=>word.charAt(0).toUpperCase()+word.slice(1)).join('')
}
console.log(camelcase("hello world")); // "HelloWorld"