function capitalizeFirstLetter(str) {
  if (typeof str !== 'string' || str.length === 0) {
    return str; // Return the original string if it's not valid
  }
  return str.split(" ").map((word)=>word.charAt(0).toUpperCase()+word.slice(1)).join(' '); // Capitalize the first letter of each word
}

console.log(capitalizeFirstLetter("hello world")); // "Hello World"