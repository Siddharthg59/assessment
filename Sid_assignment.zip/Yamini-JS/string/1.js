const temp ="harry";

console.log(typeof temp==='string');
