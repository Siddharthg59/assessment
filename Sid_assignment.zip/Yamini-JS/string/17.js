function string_chop(str, size) {
  if (!size) return [str]; // default case if no size is provided

  let result = [];
  for (let i = 0; i < str.length; i += size) {
    result.push(str.slice(i, i + size));
  }
  return result;
}
