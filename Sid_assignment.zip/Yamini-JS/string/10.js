function swapcase(str) {
  return str
    .split('')
    .map(char => {
      if (char === char.toUpperCase()) {
        return char.toLowerCase();
      } else {
        return char.toUpperCase();
      }
    })
    .join('');
}
console.log(swapcase("Hello World")); // "hELLO wORLD"
console.log(swapcase("hElLo WoRlD")); // "HeLlO wOrLd"