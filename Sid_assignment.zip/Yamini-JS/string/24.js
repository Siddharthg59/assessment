function truncatetowords(str,count){
    const words = str.split(" ");
    const res=[];
    for(let i=0;i<words.length;i++){
        if(i<count){
            res.push(words[i]);
        }
    }
    return res.join(" ");

}
console.log(truncatetowords("The quick brown fox jumps over the lazy dog", 4)); // "The quick brown fox"