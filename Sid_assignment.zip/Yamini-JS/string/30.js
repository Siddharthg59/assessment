function string_endsWith(str, suffix) {
  if (suffix === '') return false; // As per your test case

  // Compare the end substring of str with suffix
  return str.slice(-suffix.length) === suffix;
}

// Test cases:
console.log(string_endsWith('JS PHP PYTHON', 'PYTHON')); // true
console.log(string_endsWith('JS PHP PYTHON', ''));       // false
