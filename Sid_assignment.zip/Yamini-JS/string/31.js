function escape_html(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')   // Replace & first to avoid double escaping
        .replace(/</g, '&lt;')    // Replace <
        .replace(/>/g, '&gt;')    // Replace >
        .replace(/"/g, '&quot;')  // Replace "
        .replace(/'/g, '&#39;');  // Replace '
}
