function ascii_to_hexa(str) {
  let result = '';
  for (let i = 0; i < str.length; i++) {
    // Get ASCII code of each character and convert to hex with toString(16)
    let hex = str.charCodeAt(i).toString(16);
    // Make sure each hex code is 2 digits by padding with 0 if needed
    if (hex.length < 2) hex = '0' + hex;
    result += hex;
  }
  return result.toUpperCase();
}

// Test cases:
console.log(ascii_to_hexa('12'));    // Output: "3132"
console.log(ascii_to_hexa('100'));   // Output: "313030"
