function remove_non_ascii(str) {
  // Replace all chars NOT in printable ASCII range with empty string
  return str.replace(/[^\x20-\x7E]/g, '');
}

// Test:
console.log(remove_non_ascii('äÄçÇéÉêPHP-MySQLöÖÐþúÚ'));  // Output: "PHP-MySQL"
