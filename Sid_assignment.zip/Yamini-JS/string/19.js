function escape_HTML(str) {
    if (!str) return '';
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}


// What does the second parameter do?
// Replace pattern	Replacement (second parameter)	What it means
// /&/g	"&amp;"	Replace & with &amp; (HTML entity for &)
// /</g	"&lt;"	Replace < with &lt; (HTML entity for <)
// />/g	"&gt;"	Replace > with &gt; (HTML entity for >)
// /"/g	"&quot;"	Replace " with &quot; (HTML entity for ")
// /'/g	"&#39;"	Replace ' with &#39; (HTML entity for ')