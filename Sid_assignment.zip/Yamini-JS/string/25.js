function alphabetize_string(str) {
    // Remove spaces and convert to array of characters
    const chars = str.replace(/\s+/g, '').split('');

    // Sort characters case-insensitively (A-Z, a-z)
    chars.sort((a, b) => a.toUpperCase().localeCompare(b.toUpperCase()));

    // Join back into a string
    return chars.join('');
}
