function removechars(str,cnt){
    const chartoremvecnt=str.length-cnt;
    return str.slice(-chartoremvecnt);
}

console.log(removechars("hello world",5)); // "world"