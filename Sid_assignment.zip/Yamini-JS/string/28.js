function hex_to_ascii(hexStr) {
  let result = '';
  // Process every two hex digits (1 byte)
  for (let i = 0; i < hexStr.length; i += 2) {
    // Take 2 hex digits
    const hexByte = hexStr.substr(i, 2);
    // Convert hex to decimal, then to ASCII char
    result += String.fromCharCode(parseInt(hexByte, 16));
  }
  return result;
}

// Test cases:
console.log(hex_to_ascii('3132'));    // Output: "12"
console.log(hex_to_ascii('313030'));  // Output: "100"
