function sentenceCase(str) {
  return str
    .toLowerCase()                // convert entire string to lowercase first
    .split(' ')                   // split string into words by spaces
    .map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)  // capitalize first letter + rest of the word
    )
    .join(' ');                   // join words back with spaces
}

// Test:
console.log(sentenceCase('PHP exercises. python exercises.'));  
// Output: "Php Exercises. Python Exercises."
