function strip_html_tags(str) {
  return str.replace(/<[^>]*>/g, '');
}

// Test:
console.log(strip_html_tags('<p><strong><em>PHP Exercises</em></strong></p>')); 
// Output: "PHP Exercises"


// Explanation:
// The regex <[^>]*> matches any substring starting with <, followed by any characters except > ([^>]), repeated 0 or more times (*), and ending with >.

// So it matches tags like <p>, </p>, <strong>, etc.

// .replace(/<[^>]*>/g, '') removes all these tags from the string.