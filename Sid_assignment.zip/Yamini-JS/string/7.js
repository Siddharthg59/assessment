function string_parameterize(str) {
    return str
        .toLowerCase()                    // Convert to lowercase
        .trim()                          // Trim leading/trailing whitespace
        .replace(/[^a-z0-9\s-]/g, '')   // Remove all non-alphanumeric, non-space, non-hyphen chars
        .replace(/[\s-]+/g, '-')         // Replace spaces and multiple hyphens with a single hyphen
        .replace(/^-+|-+$/g, '');        // Remove leading and trailing hyphens
}
