function removeFirstOccWord(str, wordToRemove) {
  const words = str.split(' ');
  let removed = false;
  const result = [];

  for (const word of words) {
    if (!removed && word === wordToRemove) {
      removed = true; // remove first exact match
    } else {
      result.push(word);
    }
  }

  return result.join(' ');
}

console.log(removeFirstOccWord("The quick brown fox jumps over the lazy dog", "the")); 
// Output: "The quick brown fox jumps over lazy dog"

console.log(removeFirstOccWord("The quick brown fox jumps over the lazy dog", "The")); 
// Output: "quick brown fox jumps over the lazy dog"
