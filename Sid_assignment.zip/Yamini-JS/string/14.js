function insert(original, insertText = '', position = 1) {
  // Adjust for 1-based index (convert to 0-based)
  const index = position - 1;

  // Insert the text by slicing and joining
  return original.slice(0, index) + insertText + original.slice(index);
}
