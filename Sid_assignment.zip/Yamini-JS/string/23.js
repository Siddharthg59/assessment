function strip(str) {
  return str.trim();
}

