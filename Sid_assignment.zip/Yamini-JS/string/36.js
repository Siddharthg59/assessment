function zeroFill(number, width, sign = '') {
  const numStr = Math.abs(number).toString().padStart(width, '0'); // zero-fill absolute number

  if (sign === '+') {
    return '+' + numStr;
  } else if (sign === '-') {
    return '-' + numStr;
  } else {
    return numStr; // no sign, just zero-filled number
  }
}

// Tests:
console.log(zeroFill(120, 5, '+')); // "+00120"
console.log(zeroFill(120, 5, '-')); // "-00120"
console.log(zeroFill(29, 4));       // "0029"
