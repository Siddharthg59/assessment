function formatted_string(formatStr, str, direction) {
    str = str.toString();
    const totalLength = formatStr.length;

    if (direction === 'l') {
        // Left pad: add formatStr chars to the left of str until total length is reached
        return (formatStr + str).slice(-totalLength);
    } else {
        // Right pad (default): add formatStr chars to the right of str until total length is reached
        return (str + formatStr).slice(0, totalLength);
    }
}
