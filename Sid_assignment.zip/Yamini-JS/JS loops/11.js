function computeGCD(a, b) {
  while (b !== 0) {
    let temp = b;
    b = a % b;
    a = temp;
  }
  return a;
}

// Example usage:
let num1 = 60;
let num2 = 36;

let gcd = computeGCD(num1, num2);
console.log("GCD of " + num1 + " and " + num2 + " is: " + gcd);
