console.log("3-digit Armstrong numbers:");

for (let num = 100; num <= 999; num++) {
  let digits = num.toString().split(""); // Get individual digits as array
  let sum = 0;

  for (let i = 0; i < digits.length; i++) {
    sum += Math.pow(parseInt(digits[i]), 3); // Cube each digit and add to sum
  }

  if (sum === num) {
    console.log(num); // If sum equals original number, it's an Armstrong number
  }
}
