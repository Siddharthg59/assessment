let numbers = [-5, -2, -6, 0, -1];
let largest = numbers[0];

for (let i = 1; i < numbers.length; i++) {
  if (numbers[i] > largest) {
    largest = numbers[i];
  }
}

console.log("The largest number is " + largest);
