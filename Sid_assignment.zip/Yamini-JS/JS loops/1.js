// let a = parseInt(prompt("Enter the first number:"));
// let b = parseInt(prompt("Enter the second number:"));
a = 1
b = 2

if (a > b) {
  console.log("The larger number is: " + a);
} else if (b > a) {
  console.log("The larger number is: " + b);
} else {
  console.log("Both numbers are equal.");
}
