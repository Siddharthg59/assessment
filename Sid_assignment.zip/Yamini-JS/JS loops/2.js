let num1 = 3;
let num2 = -7;
let num3 = 2;
let product = num1 * num2 * num3;

if (product > 0) {
  alert("The sign is +");
} else if (product < 0) {
  alert("The sign is -");
} else {
  alert("The product is 0");
}
