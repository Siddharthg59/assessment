let x = 0, y = -1, z = 4;
let nums = [x, y, z];

nums.sort(function(a, b) {
  return b - a;
});

console.log(nums.join(", "));
console.log(" .join(", ") converts the sorted array into a comma-separated string.")

