function timecvt(minutes)
{
    console.log(`${Math.floor(minutes/60)} hours and ${minutes%60} minutes`)
}
timecvt(200)