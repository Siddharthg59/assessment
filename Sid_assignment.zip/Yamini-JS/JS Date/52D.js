// 52. Write a JavaScript function to get the month start date

function monthStart()
{
    
}