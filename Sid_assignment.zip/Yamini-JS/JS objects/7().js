function substr(str)
{
    
}