// Get the current page URL
// in google 
let currentURL = window.location.href;


console.log("Current URL:", currentURL);
