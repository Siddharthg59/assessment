function isValidURL(url) {
  const pattern = /^(https?:\/\/)?(www\.)?[a-zA-Z0-9\-]+(\.[a-zA-Z]{2,})+(\/[^\s]*)?$/;
  return pattern.test(url);
}

// Test cases
console.log(isValidURL("http://example.com"));        // true
console.log(isValidURL("https://www.google.com"));    // true
console.log(isValidURL("www.test-site.org"));         // true
console.log(isValidURL("test.com/path/to/page"));     // true
console.log(isValidURL("ftp://invalid-protocol.com")); // false
console.log(isValidURL("http:/invalid.com"));         // false
console.log(isValidURL("invalid_domain"));            // false
