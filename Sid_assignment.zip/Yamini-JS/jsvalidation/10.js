function isAlphaNumeric(str) {
  // ^ = start, $ = end, [a-zA-Z0-9]+ = one or more letters or digits
  const pattern = /^[a-zA-Z0-9]+$/;
  return pattern.test(str);
}

// Test cases
console.log(isAlphaNumeric("abc123"));     // true
console.log(isAlphaNumeric("abc123!"));    // false (contains '!')
console.log(isAlphaNumeric("123"));        // true
console.log(isAlphaNumeric("abc"));        // true
console.log(isAlphaNumeric("abc 123"));    // false (contains space)
console.log(isAlphaNumeric(""));           // false (empty string)
