function isHex(value) {
  // Matches optional 0x or #, then one or more hex digits
  const pattern = /^(0x|#)?[0-9A-Fa-f]+$/;
  return pattern.test(value);
}

// Test cases
console.log(isHex("0x1A3F"));   // true
console.log(isHex("#FFAA33"));  // true
console.log(isHex("1A3F"));     // true
console.log(isHex("GHI123"));   // false (G,H,I are invalid)
console.log(isHex("123Z"));     // false (Z invalid)
console.log(isHex(""));         // false (empty string)
