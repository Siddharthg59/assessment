function isFirstCharUppercase(str) {
  if (str.length === 0) return false; // Empty string check

  // Check if the first character matches uppercase A-Z using regex
  return /^[A-Z]/.test(str);
}
