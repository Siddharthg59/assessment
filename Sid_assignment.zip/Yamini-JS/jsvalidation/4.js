function findDateInString(text) {
  const datePattern = /\b\d{2}[-/.]\d{2}[-/.]\d{4}\b/g;
  const matches = text.match(datePattern);
  return matches || [];
}

// Test cases
console.log(findDateInString("The event is on 22/06/2025."));         // ["22/06/2025"]
console.log(findDateInString("Meeting: 15-07-2023 or 20.08.2024"));   // ["15-07-2023", "20.08.2024"]
console.log(findDateInString("No date here!"));                       // []
