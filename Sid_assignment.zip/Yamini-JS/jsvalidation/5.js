function customTrim(str) {
  return str.replace(/^\s+|\s+$/g, '');
}

// Test cases
console.log(customTrim("   Hello World!   "));  // "Hello World!"
console.log(customTrim("\t\n  OpenAI GPT-4 \n"));  // "OpenAI GPT-4"
console.log(customTrim("NoSpaces"));  // "NoSpaces"
