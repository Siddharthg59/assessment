function isValidCanadaPostalCode(postalCode) {
  // Regex explanation below
  const pattern = /^[ABCEGHJ-NPRSTVXY]\d[ABCEGHJ-NPRSTV-Z] ?\d[ABCEGHJ-NPRSTV-Z]\d$/i;
  return pattern.test(postalCode.trim());
}

// Test cases
console.log(isValidCanadaPostalCode("K1A 0B1"));  // true
console.log(isValidCanadaPostalCode("B2C3D4"));   // false (missing space)
console.log(isValidCanadaPostalCode("K1A0B1"));   // true (space optional)
console.log(isValidCanadaPostalCode("W1A 0B1"));  // false (W is not valid first letter)
console.log(isValidCanadaPostalCode("Z1A 0B1"));  // false (Z not valid)
