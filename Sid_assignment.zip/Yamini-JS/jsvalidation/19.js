function containsHTML(str) {
  // Regex matches any HTML tag like <tag> or </tag> or <tag attr="value">
  const pattern = /<("[^"]*"|'[^']*'|[^'">])*>/;
  return pattern.test(str);
}

// Test cases
console.log(containsHTML("<div>Hello</div>"));          // true
console.log(containsHTML("Just a plain text"));         // false
console.log(containsHTML("<img src='image.jpg' />"));   // true
console.log(containsHTML("Text with <br> line break")); // true
console.log(containsHTML("No tags here!"));             // false
