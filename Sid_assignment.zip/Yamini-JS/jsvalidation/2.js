// function isValidCreditCardNumber(cardNumber) {
//   // Remove spaces or dashes if any
//   const cleaned = cardNumber.replace(/[\s-]/g, '');
  
//   // Check if cleaned number has only digits and length between 13 and 19
//   const regex = /^\d{13,19}$/;
//   return regex.test(cleaned);
// }


function isSimpleCreditCard(number) {
  // Remove spaces or dashes
  const cleaned = number.replace(/[\s-]/g, '');

  // Check: is it exactly 16 digits?
  const pattern = /^\d{16}$/;
  return pattern.test(cleaned);
}

// Test cases
console.log(isSimpleCreditCard("1234567890123456"));     // true
console.log(isSimpleCreditCard("1234-5678-9012-3456"));  // true
console.log(isSimpleCreditCard("1234 5678 9012 3456"));  // true
console.log(isSimpleCreditCard("1234 5678 9012"));       // false
console.log(isSimpleCreditCard("abcd efgh ijkl mnop"));  // false
