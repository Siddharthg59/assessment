function isHexColor(value) {
  // Matches # followed by exactly 3 or 6 hex digits
  const pattern = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;
  return pattern.test(value);
}

// Test cases
console.log(isHexColor("#FFF"));      // true
console.log(isHexColor("#ff0033"));   // true
console.log(isHexColor("#123abc"));   // true
console.log(isHexColor("#123abz"));   // false (z not hex)
console.log(isHexColor("123abc"));    // false (missing #)
console.log(isHexColor("#1234"));     // false (length not 3 or 6)
