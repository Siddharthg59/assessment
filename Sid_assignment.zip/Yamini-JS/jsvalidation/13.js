function isValidUKPostcode(postcode) {
  // UK postcode regex (case insensitive)
  const pattern = /^([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9][A-Za-z]?))))\s?[0-9][A-Za-z]{2})$/;
  return pattern.test(postcode.trim());
}

// Test cases
console.log(isValidUKPostcode("EC1A 1BB"));   // true
console.log(isValidUKPostcode("W1A 0AX"));    // true
console.log(isValidUKPostcode("M1 1AE"));     // true
console.log(isValidUKPostcode("B33 8TH"));    // true
console.log(isValidUKPostcode("CR2 6XH"));    // true
console.log(isValidUKPostcode("DN55 1PT"));   // true
console.log(isValidUKPostcode("INVALID"));    // false
console.log(isValidUKPostcode("EC1A1BB"));    // true (space optional)
