function containsAlphaDashUnderscore(value) {
  // Regex explanation below
  const pattern = /^[A-Za-z-_]+$/;
  return pattern.test(value);
}

// Test cases
console.log(containsAlphaDashUnderscore("abc_DEF-ghi"));  // true
console.log(containsAlphaDashUnderscore("abc123"));       // false (digits not allowed)
console.log(containsAlphaDashUnderscore("abc def"));      // false (space not allowed)
console.log(containsAlphaDashUnderscore("abc_def-"));     // true
console.log(containsAlphaDashUnderscore(""));             // false (empty string)
