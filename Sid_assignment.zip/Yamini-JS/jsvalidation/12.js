function isValidUSZip(zip) {
  const pattern = /^\d{5}(-\d{4})?$/;
  return pattern.test(zip);
}

// Test cases
console.log(isValidUSZip("12345"));       // true
console.log(isValidUSZip("12345-6789"));  // true
console.log(isValidUSZip("1234"));        // false (only 4 digits)
console.log(isValidUSZip("123456"));      // false (6 digits)
console.log(isValidUSZip("12345-678"));   // false (only 3 digits after hyphen)
console.log(isValidUSZip("12345_6789"));  // false (underscore instead of hyphen)
