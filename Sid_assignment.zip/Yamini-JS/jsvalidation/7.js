function isValidIP(ip) {
  const pattern = /^(25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)){3}$/;
  return pattern.test(ip);
}

// Test cases
console.log(isValidIP("192.168.1.1"));     // true
console.log(isValidIP("255.255.255.255")); // true
console.log(isValidIP("256.100.50.0"));    // false (256 is invalid)
console.log(isValidIP("192.168.1"));       // false (only 3 parts)
console.log(isValidIP("abc.def.ghi.jkl")); // false (not numbers)
