function isValidDomain(domain) {
  const pattern = /^(?=.{1,253}$)(?!\-)([a-zA-Z0-9\-]{1,63}\.)+[a-zA-Z]{2,63}$/;
  return pattern.test(domain);
}

// Test cases
console.log(isValidDomain("example.com"));          // true
console.log(isValidDomain("sub.example.co.uk"));    // true
console.log(isValidDomain("-example.com"));         // false (starts with hyphen)
console.log(isValidDomain("example-.com"));         // false (label ends with hyphen)
console.log(isValidDomain("ex_ample.com"));         // false (underscore invalid)
console.log(isValidDomain("example.c"));            // false (TLD too short)
console.log(isValidDomain("example.123"));          // false (TLD must be letters)
console.log(isValidDomain("ex..ample.com"));        // false (double dot)
