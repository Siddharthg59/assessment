function isValidTime(time) {
  // Regex explanation below
  const pattern = /^([01]\d|2[0-3]):([0-5]\d)(:([0-5]\d))?$/;
  return pattern.test(time);
}

// Test cases
console.log(isValidTime("00:00"));     // true
console.log(isValidTime("23:59"));     // true
console.log(isValidTime("12:30:45"));  // true
console.log(isValidTime("24:00"));     // false (invalid hour)
console.log(isValidTime("12:60"));     // false (invalid minutes)
console.log(isValidTime("12:30:60"));  // false (invalid seconds)
console.log(isValidTime("7:30"));      // false (hour should be two digits)
