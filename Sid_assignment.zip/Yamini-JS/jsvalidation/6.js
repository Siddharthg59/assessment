function countWords(str) {
  // 1. Remove leading/trailing spaces
  str = str.trim();

  // 2. Replace multiple spaces (and tabs) with a single space
  str = str.replace(/\s{2,}/g, ' ');

  // 3. Remove lines that start with whitespace + newline
  str = str.replace(/^\s*\n/gm, '');

  // 4. Split by single space
  const words = str.split(' ').filter(word => word.length > 0);

  return words.length;
}

// Test cases
console.log(countWords("   Hello   world   "));            // 2
console.log(countWords("This   is  a   test."));           // 4
console.log(countWords("   \nOpenAI\n GPT-4  "));          // 2
console.log(countWords("Line1\n  \n  Line2   "));          // 2
