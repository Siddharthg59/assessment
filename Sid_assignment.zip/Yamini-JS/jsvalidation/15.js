function isValidSSN(ssn) {
  // Regex explanation below
  const pattern = /^\d{3}-\d{2}-\d{4}$/;
  return pattern.test(ssn);
}

// Test cases
console.log(isValidSSN("123-45-6789"));   // true
console.log(isValidSSN("123456789"));     // false (missing dashes)
console.log(isValidSSN("12-345-6789"));   // false (incorrect format)
console.log(isValidSSN("123-45-678"));    // false (last part too short)
console.log(isValidSSN("123-45-67890"));  // false (last part too long)
