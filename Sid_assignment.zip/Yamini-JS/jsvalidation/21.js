function thousands_separators(num) {
  // Convert number to string
  const numStr = num.toString();
  
  // Split integer and decimal parts
  const parts = numStr.split(".");
  
  // Add commas to integer part using regex
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  
  // Join integer and decimal parts back
  return parts.join(".");
}

// Test cases
console.log(thousands_separators(1000));       // "1,000"
console.log(thousands_separators(10000.23));   // "10,000.23"
console.log(thousands_separators(100000));     // "100,000"
console.log(thousands_separators(9876543210)); // "9,876,543,210"
console.log(thousands_separators(1234.5678));  // "1,234.5678"
