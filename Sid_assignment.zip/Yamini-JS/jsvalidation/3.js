function isValidEmail(email) {
  const emailPattern = /^[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/;
  return emailPattern.test(email);
}

// Test cases
console.log(isValidEmail("user.name+tag@example.com"));     // true
console.log(isValidEmail("username@example.co.uk"));        // true
console.log(isValidEmail(".username@example.com"));         // false
console.log(isValidEmail("username.@example.com"));         // false
console.log(isValidEmail("user..name@example.com"));        // false
console.log(isValidEmail("username@example"));              // false
