function returnLexicographicOrder(str) {
  // Sort the array in lexicographic order
  return str.split('').sort().join('');
}
console.log(returnLexicographicOrder("hello")); // Output: "ehllo"