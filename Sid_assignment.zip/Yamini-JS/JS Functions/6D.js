// const a = "ad dfe er e"
// console.log(a.split(' ')[0].length)
