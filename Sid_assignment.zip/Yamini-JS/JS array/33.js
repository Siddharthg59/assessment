// 33. Write a JavaScript script to empty an array keeping the original.  

var array = [1,2,4,5,6,7,7]
array.splice(0,array.length)
console.log(array)