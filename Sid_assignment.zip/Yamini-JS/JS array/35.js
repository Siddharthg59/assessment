var array = [2,4,5,6,7,8,3,6,4]
var random = Math.floor(Math.random()*(array.length + 1))
console.log(array[random])